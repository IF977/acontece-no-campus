Given(/^que eu estou na página do formulario$/) do
 visit "users/sign_up"
end

When(/^eu preencher todos os campos$/) do
  fill_in "user_email", :with=> "rms11@cin.ufpe.br"
  fill_in "user_password", :with=> "12345678"
end

When(/^clicar em "([^"]*)"$/) do |sign_up|
  click_link_or_button("sign_up")
  save_and_open_page
end

Then(/^deve ver receber a mensagem "([^"]*)"$/) do |arg1|
  pending # Write code here that turns the phrase above into concrete actions
end