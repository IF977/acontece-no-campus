class ApplicationMailer < ActionMailer::Base
  default from: "rms11@cin.ufpe.br"
  layout 'mailer'
end
