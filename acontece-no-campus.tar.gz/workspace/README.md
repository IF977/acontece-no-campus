# acontece-no-campus
O projeto "Acontece no Campus" é um sistema de gestão de eventos e atividades que ocorrem no campus da universidade utilizado como tema na disciplina de Engenharia de Software (IF977) do curso de Sistemas de Informação da UFPE.
